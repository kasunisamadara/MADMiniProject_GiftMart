package com.example.madminiproject;

import android.view.View;

public interface ItemClickListner {

    Void onClick(View view, int position, boolean isLongClick);
}
